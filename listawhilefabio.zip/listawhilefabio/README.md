# Lista-Fabio-While01
Lista de while do professor fabio, parte 1
