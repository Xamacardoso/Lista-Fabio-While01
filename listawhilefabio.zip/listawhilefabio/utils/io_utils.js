import { question } from "readline-sync";

export function getnumber(message) {
    return Number(question(message))
}

export function getstring(message) {
    return String(question(message))
}

export function write(message) {
    console.log(message)
}

export function mmc(n1, n2) {
    let resto
    let x
    let y
    x = n1
    y = n2
    while(resto != 0){
       resto = x % y
       x = y
       y = resto
    }
      return (n1*n2)/x
}

export function mdc(n1, n2) {
    let resto
    let x = n1
    let y = n2
    while (resto != 0) {
        resto = x % y
        x = y
        y = resto
    }
    return x
}

export function casas(num) {
    let casas = 1
    let ordem = 10
    while (ordem <= Math.abs(num)){
        casas += 1
        ordem *= 10
    }
    return casas
}

export function lista_numeros_ate(num){
    let lista = ''
    let elemento = getnumber("Digite um numero para fazer uma lista: ")
    lista += `${elemento}`
    while (elemento != num){
        elemento = getnumber("Digite outro numero: ")
        if (elemento != num){
            lista += ` ${elemento}`
        }
    }
    return lista
}

export function lista_consecutivos(num){
    let aux = 0
    let num_lista = getnumber("Digite um numero da lista: ")
    let lista = `${num_lista}`
    while ((num_lista + aux) != num){
        aux = num_lista
        num_lista = getnumber('Digite outro numero da lista: ')
        lista += ` ${num_lista}`
    }
    
    return lista
}

export function media3(){
    let nota1 = getnumber('Nota 1: ')
    while (nota1 > 10 || nota1 < 0){
        write('Valor inválido! Digite um valor entre 0 e 10.')
        nota1 = getnumber('Nota 1: ')
    }

    let nota2 = getnumber('Nota 2: ')
    while (nota2 > 10 || nota2 < 0){
        write('Valor inválido! Digite um valor entre 0 e 10.')
        nota2 = getnumber('Nota 2: ')
    }

    let nota3 = getnumber('Nota 3: ')
    while (nota3 > 10 || nota3 < 0){
        write('Valor inválido! Digite um valor entre 0 e 10.')
        nota3 = getnumber('Nota 3: ')
    }
    const media = ((2*nota1) + (3*nota2) + (5*nota3))/10

    return media.toFixed(1)
}